"""
텔레그램 채널 리스너 — Oracle Cloud VM(sosopro)에서 24시간 실행.

4개 채널(@NEWSZZANG, @FASTSTOCKNEWS, @MONEYTHEMESTOCK, @morefaternews)에
새 메시지가 올라오면 즉시 감지해서, 뉴스매매 사이트의 /api/telegram-ingest
엔드포인트로 그 내용을 POST로 전송합니다. 사이트 쪽은 그 메시지를 기존 뉴스
필터링·관련주 매칭 파이프라인(Naver 뉴스 폴링과 완전히 동일한 로직)에 그대로
태워서, 통과하면 피드에 자동 게재합니다.

[2026-09-08 변경] 오늘 아침 추가했던 채널 2개(@morefaternews,
@characteristicstock) 중 @characteristicstock은 재성님 요청으로 다시 뺌 —
텔레그램에서 그 채널을 나가면(구독 취소) 새 글 자체가 더 이상 이 계정으로
안 들어오지만, 코드에도 남겨두면 다음에 이 프로그램을 재시작할 때 이미 나간
채널이라 상태 조회 과정에서 오류가 날 수 있어서 CHANNELS 목록에서도 지움.
@morefaternews는 그대로 유지.

── 사용법 ──────────────────────────────────────────────────────────
1. 아래 "설정" 구역의 INGEST_URL, INGEST_SECRET 값을 실제 값으로 채운다
   (자세한 건 이 zip에 같이 들어있는 README_설치안내.md 참고).
2. 서버에 이 파일을 올린다 (~/telegram-news/listener.py 로 덮어쓰기).
3. (최초 1회만) requests 라이브러리 설치:
     pip install requests
4. 실행:
     python listener.py
   최초 실행 시에는 텔레그램이 전화번호 + 인증코드를 입력하라고 물어봄
   (텔레그램 앱으로 코드가 옴). 한 번 로그인하면 session_name.session
   파일이 생겨서, 이후로는 다시 로그인 안 해도 됨.
5. 정상 작동 확인되면, systemd로 등록해서 24시간 자동 실행되게 설정
   (server/telegram-listener.service, README 참고).
"""

import requests
from telethon import TelegramClient, events

# ── 설정 (여기만 필요시 수정) ──────────────────────────────────────────
API_ID = 32957338
API_HASH = "4d3386a75c99658bd4044fd0e3696407"

CHANNELS = ["@NEWSZZANG", "@FASTSTOCKNEWS", "@MONEYTHEMESTOCK", "@morefaternews"]

# TODO: 실제 배포 도메인 확인 후 필요하면 수정하세요.
# (Cloudflare로 완전히 넘어간 뒤의 최종 도메인이 newsmeme.co.kr이 맞는지
#  재성님이 확인해주셔야 합니다 — 다를 경우 여기만 바꾸면 됩니다.)
INGEST_URL = "https://newsmeme.co.kr/api/telegram-ingest"

# 아래 값은 미리 하나 생성해둔 값입니다. 이 값을 Cloudflare 대시보드의
# "Build variables and secrets"에 TELEGRAM_INGEST_SECRET 이라는 이름으로
# 정확히 동일하게 등록해야 서버가 이 리스너의 요청을 인증할 수 있습니다.
INGEST_SECRET = "gdOWyVBiT1GBXClK0RP3gxQXH83W6Xh436gF1UHA--c"
# ────────────────────────────────────────────────────────────────────

client = TelegramClient("session_name", API_ID, API_HASH)


def send_to_site(channel, message_id, text, date_iso):
    try:
        res = requests.post(
            INGEST_URL,
            headers={
                "Authorization": f"Bearer {INGEST_SECRET}",
                "Content-Type": "application/json",
            },
            json={
                "channel": channel,
                "messageId": message_id,
                "text": text,
                "date": date_iso,
            },
            timeout=30,
        )
        print(f"  -> 사이트 응답 ({res.status_code}): {res.text[:200]}")
    except Exception as e:
        # 네트워크 오류 등으로 전송 실패해도 리스너 자체는 죽지 않고 계속
        # 다음 메시지를 기다립니다 — 한 번 실패했다고 24시간 감시가
        # 멈추면 안 되니까요.
        print(f"  -> 사이트 전송 실패: {e}")


@client.on(events.NewMessage(chats=CHANNELS))
async def handler(event):
    channel = ("@" + event.chat.username) if getattr(event.chat, "username", None) else str(event.chat_id)
    text = event.raw_text or ""
    message_id = event.id
    date_iso = event.date.isoformat() if event.date else None

    print(f"\n[새 메시지] {channel} (id={message_id})")
    print(text[:200])
    print("-" * 40)

    if text.strip():
        send_to_site(channel, message_id, text, date_iso)


print("리스너 시작됨. 종료하려면 Ctrl+C")
client.start()
client.run_until_disconnected()
